#include <iostream>
using namespace std;

class Brain{
	private:
		int iqLevel;
	
	public:
		Brain(){
			iqLevel=0;
		}
		Brain(int iq){
			this->iqLevel=iq;
		}
		
		void display(){
			cout<<"iqLevel is : "<<iqLevel<<endl;
		}
		
};

class Heart{
	private:
		string side;
		
	public:
		Heart(){
			side="None ";
		}
		
		Heart(string s){
			this->side=s;			
		}
		
		void dispaly(){
			cout<<"On which side is heart present : "<<side<<endl;
		}
};

class Legs{
	private:
		int l;
		
	public:
		Legs(){
			l=0;			
		}
		
		Legs(int leg){
			this->l=leg;			
		}
		
		void display(){
			cout<<"Legs = "<<l<<endl;
		}
};

class Person{
	private:
		string name;
		Brain b;
		Heart h;
		Legs le;
	public:
		Person() : b(), h(), le(){
			name="No Name ";
			//b();
			//h();
			//le();
		}
		Person(string name, Brain b, Heart h, Legs le) :b(b), h(h), le(le){
			this->name=name;
			
		}
		
		void display(){
			cout<<"Name = "<<name<<endl;
			b.display();
			h.dispaly();
			le.display();
		}
		
};

int main(){
	
	Brain b(30);
	b.display();
	cout<<"..........................................\n"<<endl;
	
	Heart h("left side");
	h.dispaly();
	cout<<"..........................................\n"<<endl;
	
	Legs le(2);
	le.display();
	cout<<"..........................................\n"<<endl;
	
	Person p("Nihal", b, h, le);
	p.display();
	cout<<".........................................."<<endl;
	
	
}
