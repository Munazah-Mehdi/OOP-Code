#include <iostream>
using namespace std;

class Employee{
	private:
		string empName;
		int empNumber;
		
	public:
		Employee(){
			empName="NO Name";
			empNumber=0;
		}
		
		Employee(string name, int num){
			this->empName=name;
			this->empNumber=num;
			
		}
		
		void display(){
			cout<<"Employee Name : "<<empName<<endl;
			
			cout<<"Employee Number : "<<empNumber<<endl;			
		}	
};

class Manager : public Employee{
	private:
		char title;
		double clubDues;
		
	public:
	Manager(){
		title=' ';
		clubDues=0.0;		
	}
	Manager(string name, int num,char title, double dues): Employee(name, num)
	{
		this->title=title;
		this->clubDues=dues;		
	}
	void display(){
		Employee::display();
		cout<<"Title : "<<title<<endl;
		cout<<"clubDues : "<<clubDues<<endl;
		
	}
};

class Scientist : public Employee{
	private:
		int publications;
		
	public:
		Scientist(){
			publications=0;
		}
		
		Scientist(string name, int num, int pub): Employee(name, num)
		{
			this->publications=pub;
		}
		
		void display(){
			Employee::display();
			cout<<"Publications : "<<publications<<endl;
		}
		
};

class Programmer : public Employee{
	private:
		double salary;
		string expertise;
		
	public:
		Programmer(){
			salary=0.0;
			expertise="None";
		}
		Programmer(string name, int num, double salary, string expertise): Employee(name, num)
		{
			this->salary=salary;
			this->expertise=expertise;
		}
		
		void display(){
			Employee::display();
			cout<<"Salary : "<<salary<<endl;
			cout<<"Expertise : "<<expertise<<endl;
		}
};

int main(){
	Manager m ,	m1("Nihal", 21786, 'k', 123.321);
	m.display();
	cout<<endl;
	m1.display();
	cout<<"..........................................\n"<<endl;
	
	Scientist s, s1("Nihal", 21786, 1 );
	s.display();
	cout<<endl;
	s1.display();
	cout<<"..........................................\n"<<endl;
		
	Programmer p, p1("Nihal", 21786, 200000.123, "BCS");
	p.display();
	cout<<endl;
	p1.display();
	cout<<".........................................."<<endl;
	
	
}
