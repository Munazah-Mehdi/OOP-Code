// Q No # 2
#include <iostream>
using namespace std;

//Create a SavingsAccount class.
class savingAccount{
	private:
		//Use a static data member annualInterestRate to store the annual interest rate
		static float annualInterestRate;
		
		//data member savingsBalance indicating the amount the saver currently has on deposit.
		float savingsBalance;
	public:
		
		//a static member function modifyInterestRate 
		static void modifyInterestRate(){
			/*that sets the static annualInterestRate to 4%
			4 % => 4/100 = 0.04 */
			annualInterestRate=0.04;
			}
		
		void setBalance(float b){
			savingsBalance=b;
		}
		//member function calculateMonthlyInterest
		void calculateMonthlyInterest(){
			//multiplyingthe balance by annualInterestRate divided by 12
			float balance;
			balance=savingsBalance*annualInterestRate/12;
			//interest should be added to savingsBalance.
			savingsBalance+=balance;	
		}
		
		//a member function to display the balance of the saver.
		void display(){
			cout<<savingsBalance<<endl;
		}
};

/*Set the annualInterestRate to 3 percent
3 % => 3/100 = 0.03 */
float savingAccount::annualInterestRate=0.03;


int main(){
	savingAccount saver1, saver2;
	saver1.setBalance(2000.00);
	saver2.setBalance(3000.00);
	
	
	cout<<"The Balance of the saver 1 is = ";
	saver1.display();
	
	cout<<"The Balance of the saver 2 is = ";
	saver2.display();
	
	cout<<".........................................................................."<<endl;
	cout<<endl;
	////calculate the interest for 3%
	
	saver1.calculateMonthlyInterest();
	
	saver2.calculateMonthlyInterest();
	
	cout<<"The Balance of the saver 1 after 3% interest is = ";
	saver1.display();
	cout<<"The Balance of the saver 2 after 3% interest is = ";
	saver2.display();
	
	cout<<".........................................................................."<<endl;
	cout<<endl;
	
	//modifying interest rate
	saver1.modifyInterestRate();
	saver2.modifyInterestRate();
	
	//calculate the next month�s interest
	saver1.calculateMonthlyInterest();
	saver2.calculateMonthlyInterest();
	
	//print the new balances for each of the savers.
	cout<<"The next month's balance of the saver 1 after 4% interest is = ";
	saver1.display();
	cout<<"The next month's balance of the saver 2 after 4% interest is = ";
	saver2.display();
	
	return 0;
	
	
	
	
		
}
