// Q No # 1 
/*Create a class that includes a data member that holds a �serial number� for each object
created from the class. */

#include <iostream>
#include <sstream>
using namespace std;

class data{
	private:
	//a data member that holds a �serial number� for each object created
	string serial_num;
	//another data member that records a count of how many objects have been created
	static int count;
	
	public:
		//constructor can examine count member
		data(){
			count++;
			stringstream counter;
			counter<<count;
			string num;
			counter >>num;
			this->serial_num="2022FAST0"+num+"OOP";	
		}

		void display(){
			cout<<"serial Number : "<<serial_num<<endl;			
		}
};

int data::count=0;

int main(){
	//createing five objects
	data o1, o2, o3, o4, o5;
	o1.display();
	o2.display();
	o3.display();
	o4.display();
	o5.display();
	
	return 0;
}
