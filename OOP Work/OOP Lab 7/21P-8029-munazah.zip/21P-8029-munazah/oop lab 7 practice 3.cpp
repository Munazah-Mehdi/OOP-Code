#include <iostream>
using namespace std;

class prog{

	public:
		prog(){
			cout<<"contructor "<<endl;}
			
		~prog(){
			cout<<"discontructor "<<endl;}
		

};

int main(){
	prog x;
	int a, b;
	a=10;
	b=20;
	cout<<"Sum of a+b ="<<a+b<<endl;
	return 0;
}
