#include <iostream>
using namespace std;

class sum{
	private:
	int a;
	int b;
	
	public:
	sum(){
		cout<<"defualt  "<<endl;
	}
	
	sum(int a){
		int b;
		b=a+a;
		cout<<"b is = "<<b<<endl;
		
	}
	
	sum(int a, int b){
		int c;
		c=a+b;
		cout<<"c = "<<c<<endl;
		
	}
};

int main(){
	sum x, y(3), z(3,4);

}
