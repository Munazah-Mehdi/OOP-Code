//Q#3
#include <iostream>
using namespace std;

class complex{
	private:	
		float real;
		float imaginary;
		
	public:
		//to set the specified value in object
		void set(float r, float im){
			this->real=r;
			this->imaginary=im;	
		}
		
		//to display complex number object
		void disp(){
			cout<<real<<" + "<<imaginary<<"i"<<endl;
		}	
		
		//to sum two complex numbers & return complex number
		complex Sum(complex a){
			complex n;
			n.real=real+ a.real;
			n.imaginary=imaginary+a.imaginary;
			return n;
		}
};
/*1. Write the definitions for each of the above member functions?

  void disp display values
  complex sum will addup the real and imaginary parts  */
  
  
int main(){
	complex n1, n2, n3,n4;
	
	
	n1.set(1,2);
	n2.set(3,4);
	
	n3=n1.Sum(n2);
	n3.disp();

	
	return 0;
}
