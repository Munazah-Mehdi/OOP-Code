//Q#1
#include <iostream>
using namespace std;

//Create a class named 'Rectangle'
class Rectangle{
	
	//two floating point data members
	private:
		float length;
		float breadth;
	
	public:
		
		//constructors having no parameter
		Rectangle(){
			length=0;
			breadth=0;
		}
		
		//constructors having two numbers as parameters
		Rectangle(float l, float b){
			this->length=l;
			this->breadth=b;
		}
		
		//constructors having one number as parameter
		Rectangle(float x){
			
			length=x;
			breadth=x;
		}
		
		//member functions:
		//to calculate and return the area of the rectangle.
		float area(){
			return length*breadth;			
		}
		
		//to display the length and width of the rectangle
		void show(){
			cout<<"The length of rectangle = "<<length<<endl;
			cout<<"The breadth of rectangle = "<<breadth<<endl;		
		}
		
		//int sameArea(Rectangle) that that has one parameter of type Rectangle.
		int sameArea(Rectangle &r5){
			if (r5.area()==area()){
				return 1;	
			}
			
			else{
				return 0;
				}
				}
		
		//setter for new values
		void setvalue(float a, float b){
			this->length=a;
			this->breadth=b;
		}	
	//add a destructor that will display an appropriate message when called.	
	~Rectangle(){
		cout<<"Destructor has been called "<<endl;
	}	
};
/*1. Write the definitions for each of the above member functions?
    float area()  will calulate area of rectangle.
    void show()  will display the data.
    int sameArea(Rectangle)  will check the area 
  */
int main(){
	/*float L1, L2, B1, B2;
	
	cout<<"\nEnter length and breath of rectangle 1 = ";
	cin>> L1 >> B1;
	
	cout<<"\nEnter length and breath of rectangle 1 = ";
	cin>> L2 >> B2;*/
	
	
	
	//i just hard code this here, not for applying for loop.
	Rectangle r1, r2(1.4), r3(1.2, 1.5), r4(5, 2.5), r5(5, 18.9);
	//Display each rectangle and its area.
	r1.show();
	r2.show();
	r3.show();
	r4.sameArea(r5);
	
	cout<<".............................................."<<endl;
	
	
	
	if (r4.sameArea(r5)==1){
		cout<<"Area of both is same"<<endl;
	}	
	else{
		cout<<"Area of both is not same"<<endl;
	}
	
	//again assigning new values to length and breadth of r4;
	r4.setvalue(5, 18.9);
	
	
	//checking again
	if (r4.sameArea(r5)==1){
		cout<<"Area of both is same"<<endl;
	}	
	else{
		cout<<"Area of both is not same"<<endl;
	}
	
	cout<<".............................................."<<endl;
	
	return 0;
}
