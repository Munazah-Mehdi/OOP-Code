#include <iostream>
#include<string.h>
using namespace std;

class student{
	
	private:
	int roll;
	string name;
	float marks;
	
	public:
	student(){
		roll=0;
		name="munazah";
		marks=0;
	}
	student(int r, string n, float m){
		roll=r;
		name=n;
		marks=m;
	}
	
void display(){
		
		cout<<"\nRoll : "<<roll;
		cout<<"\nName : "<<name;
		cout<<"\nMarks : "<<marks;
	}
};

int main(){
	student s(2, "summit", 90.9);;
//	student(2, "summit", 90.9);
	student();
	
	s.display();
	cout<<"\n"<<endl;
	
//	s.display();
	
	return 0;
	
	
}
