//Q#2

#include <iostream>
using namespace std;

//Create a class called time
class time{
	private:
		int hours;
		int minutes;
		int seconds;
		
		
	public:
		//constructor should initialize this data to 0
		time(){
			hours=0;
			minutes=0;
			seconds=0;
		}
		//constructor initialize it to fixed values.
		
		time(int h, int m, int s){
			this->hours=h;
			this->minutes=m;
			this->seconds=s;
		}
		time operator + (time t2){
			int x, y,z,ts;
			time o;
			
			o.seconds=seconds+t2.seconds;
			o.minutes=minutes+t2.minutes;
			o.hours=hours+t2.hours;
			
			if(o.seconds>=60){
				o.seconds=o.seconds-60;
				o.minutes++;
			}
			if(o.minutes>=60){
				o.minutes=o.minutes-60;
				o.hours++;
			}
			return o;}
			
		
		//member function should display it, in 11:59:59 format
		void display(){
			cout<<"Time is = "<<hours<<" : "<<minutes<<" : "<<seconds;
		}	
		
		//modified addTime()
		
		//member function should add two objects of type time passed as arguments.
		/*void addTime(time a, time b){
			int x, y,z,ts;
			x=a.hours*3600+a.minutes*60+a.seconds;
			y=b.hours*3600+b.minutes*60+b.seconds;
			
			ts=x+y;
			
			//hours
			this->hours=ts/3600;
			
			//minutes
			z=ts%3600;
			this->minutes=z/60;
			
			//seconds
			this->seconds=z%60;		
		}	*/
};

int main(){
	//create two initialized time objects and one that isn�t initialized.
	time t1(1,22,3), t2(4,38,6), t3,t4;

	t4=t1+t2;
	t4.display();
	
	
}
