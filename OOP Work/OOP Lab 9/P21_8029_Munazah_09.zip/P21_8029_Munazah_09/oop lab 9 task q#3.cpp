//Q#3

#include <iostream>
using namespace std;

//Create a class called time
class time{
	private:
		int hours;
		int minutes;
		int seconds;
		
		
	public:
		//constructor should initialize this data to 0
		time(){
			hours=0;
			minutes=0;
			seconds=0;
		}
		//constructor initialize it to fixed values.
		
		time(int h, int m, int s){
			this->hours=h;
			this->minutes=m;
			this->seconds=s;
		}
		
		void operator ++ (){	
			++minutes;
		}
		void operator ++ (int){	
			minutes++;		
		}
		
		void operator -- (){	
			-- minutes ;
		}
		void operator -- (int){	
			minutes--;	
		}
		//member function should display it, in 11:59:59 format
		void display(){
			
			//for ++
			if(this->minutes==60){
				minutes=minutes-60;
				hours++;
			}
			
			//for --
			if(this->minutes<0){
				minutes=minutes+60;
				hours--;
			}
			cout<<"Time is = "<<hours<<" : "<<minutes<<" : "<<seconds<<endl;
		}		
		//member function should add two objects of type time passed as arguments.
		void addTime(time a, time b){
			int x, y,z,ts;
			x=a.hours*3600+a.minutes*60+a.seconds;
			y=b.hours*3600+b.minutes*60+b.seconds;
			
			ts=x+y;
			
			//hours
			this->hours=ts/3600;
			
			//minutes
			z=ts%3600;
			this->minutes=z/60;
			
			
			//seconds
			this->seconds=z%60;	
		}	
};

int main(){
	//create two initialized time objects and one that isn�t initialized.
	time t1(2,38,9), t2(3,1,0), t3;
	t3.addTime(t1,t2);
	t3.display();
	
	++t1;
	t1.display();
	t1++;
	t1.display();
	
	--t2;
	t2.display();
	t2--;
	t2.display();
	
	
	
}
