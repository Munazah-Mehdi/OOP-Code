/*Write a C++ program that ask the user to input his/her full name (firstName lastName).
Change its 5th and 10th character to underscore _*/

#include <iostream>
using namespace std;
string name;
int main(){
	string fullName;
 	cout<<"Enter full name: ";          // for dislaying on console
	getline(cin,fullName);              // getline is used to take full name  otherwise it just print out first name only.
	cout<<"Your name is :"<<fullName;
	
	fullName[4]='_';        // as 0 base indexing so 4
	fullName[9]='_';        // it will also count space
	
	cout<<"\nName after changes (It will also count space ) : "<<fullName;    // \n means next line
	return 0;
}
