//A program that takes two numbers from the user and perform all arithmetic operations.

#include <iostream>
using namespace std;
int n1, n2,sum,sub,mul;
float div,re;
int main(){
	
	cout<<"Enter first num(a) = ";                      // for dislaying on console
	cin>>n1;                                           // for taking input from console
	cout<<"Enter second num(b) = ";
	cin>>n2;
	//addition
	sum=n1+n2;
	cout<<" The sum of a+b is = "<<sum<<endl;
	
	//subraction
	sub=n1-n2;
	cout<<" The subraction of a-b is = "<<sub<<endl;
	
	//multiplication
	mul=n1*n2;
	cout<<" The multiplication of a*b is = "<<mul<<endl;
	
	//divsion
	div=(float)n1/n2;     //n1 & n2 convert in float as division is always in  float otherwise it will not show satisfied answer e.g: 2/3=0 which is not satisfied like 0.6667
	cout<<" The division is of a/b = "<<div<<endl;


    //remainder
	re=n1%n2;
	cout<<" The remainder is of a%b = "<<re<<endl;
	return 0;	}
