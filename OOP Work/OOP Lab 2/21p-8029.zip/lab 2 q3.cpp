//A program that display the last 3 digits of 5 digit num in reverse order.

#include <iostream>
using namespace std;

int n,num1,num2,num5,num4,num3;

int main(){
	
	cout<<"Enter five digits num : ";        // for dislaying on console
	cin>>n;                                  // for taking input from console 
	
	num5=n%10;  //give last digit
	n=n/10;  // give remain num 
	
	num4=n%10;  //give 2nd last digit
	n=n/10;  // give remain num 
	
	num3=n%10;  //give 3rd digit
	n=n/10;  // give remain num 
	
	num2=n%10;  // give 2nd digit  --------- but it is not needed in this code as only need to reversed last 3 digits.
	num1=n/10;  // give remain num --------- but it is not needed in this code as only need to reversed last 3 digits.
	

	cout<<"The new digit is : "<<num5<<num4<<num3;
	return 0;
	
	
	
}
