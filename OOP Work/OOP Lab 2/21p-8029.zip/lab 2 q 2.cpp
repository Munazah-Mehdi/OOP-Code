// A program in C++ that ask a user to enter radius and calculate the volume of a sphere.

#include <iostream>
#include <cmath>
using namespace std;

float r, v,a;
int pi=3.14;
int main(){
	
	cout<<"Enter radius of sphere = ";          // for dislaying on console
	cin>>r;                                     // for taking input from console 
	v=(3.14*pow(r,3))*4/3;                      // multiplying value of pi with the radius having power 3, then multiply it with 4/3
	cout<<"Volume of sphere is = "<<v;
	
	return 0;
	
	
}
