/* question no: 2

The program should ask the user to enter a
number, an operator, and another number. (Use floating point.) It should then
carry out the specified arithmetical operation: adding, subtracting, multiplying, or dividing
the two numbers. Use a switch statement to select the operation. 
*/

#include <iostream>
using namespace std;


int a, b ;

char operation, p;

int main(){
	
	while ( p!='n' || p=='y'){        //when ever user input y(yes) while wil be ture, so break only when user input n(no).
		cout<<"Enter first number, operator, second number: ";    
		cin>>a>>operation>>b;        //it will take 1st num then operator and 2nd num. 
	
	
	switch(operation){
		//addition
		case '+':
			cout<<"Answer = "<<a+b<<endl;
			break;
		//subraction
		case '-':
			cout<<"Answer = "<<a-b<<endl;
			break;
		//multilicaion	
		case '*':
			cout<<"Answer = "<<a*b<<endl;
			break;
		//division	
		case '/':
			float c=a; //changing them in float for division.
			float d=b;
			
			cout<<"Answer = "<<c/d<<endl;
			break;
			
		
			
	}
	    //asking whether the user wants to do another calculation.
    	cout<<"Do another (Enter 'y' or 'n')? ";
        cin>>p;
	
	}
	
	
	
	
	return 0;
}
