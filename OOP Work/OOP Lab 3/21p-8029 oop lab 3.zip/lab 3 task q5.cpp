//question no: 5 

#include <iostream>
using namespace std;

int s, f;


int main(){
	cout<<"Enter your salary : ";
	cin>>s;
	  
	cout<<"Salary before deduction = "<<s<<endl;
	  
	if (s>10000 && s<20000){                             // if both true then it run
		f=s-1000;  //deduct 1000 from salary
		cout<<"\nSalary after deduction = "<<f<<endl;    // print out salary after deduction of 1000
		cout<<"1000 deducted from your salary.";
	}
	
	else if (s>=20000){     // run when slary is more than 20000
		f=(float)7/100*s;         // applying 7% but also typing casting it so calculation done correctly as value of % will be in float(0.07), otherwise it will effect the answer.
		
		cout<<"\nSalary after deduction = "<<s-f<<endl;    // print out salary after deduction of 7%
		cout<<"7% deducted from your salary.";
	}
	else{
		cout<<"\nYour salary is = "<<s<<"\nNo deduction from your salary. ";   // print out salary when there is no deduction from it, when salary is less then 10000
	}
	
	  
	  
	  
	
	
	return 0;
}
