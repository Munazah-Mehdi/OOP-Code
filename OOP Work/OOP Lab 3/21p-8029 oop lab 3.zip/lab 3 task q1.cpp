/* questtion no: 1
A program that allows the user to enter the number and then generates the table, formatting it into 10 columns and
10 lines.
*/


#include <iostream>
using namespace std;

int num, a,i;

int main(){
	
	cout<<"Enter a number:  ";
	cin>>num;
	
	int count=0;     //here I take counter for printing upto 10 columns.
	
	
	for ( i=1; i<=100; i++){       //I take i<=100 as to print upto 10 columns and 10 rows(10*10=100).
		
		a=num*i;    // num will multiply with value of i every time upto 100.
		
		cout<<"\t"<<a;  // here \t for giving a tab space for printing every output.
		
		count+=1;       //It will count no. of for loop each time when it run.
		if (count>=10){ // check for printing 10 columns.......
			cout<<endl; // after printing 10 times, it ends that line and start printing in new row.
			count=0;    // at the end asign 0 to counter so it will start from 0 again when this if statement run the other time.
		}
}	
	
	return 0;
}
