/* question no: 3
Write a C++ program that will display * in the following pattern:
*****
****
***
**
*
 
*/

#include <iostream>
using namespace std;

int main(){
	//here we take two nested for loops 1 for rows and 2nd for columns, i for rows and j for columns.
	
	for(int i=1; i<=5; i++)  //1st for loop
	{
		for(int j=i; j<=5; j++) //j=i so this loop will run from value of i, as i increments,this loop will print accordingly(i.e 1st print 5 * when i=1 then print 2 * when i=2 and so on up to i=5.
		{
		cout<<"*";     
	
	}
	cout<<endl;	  //when 2nd for loop(nested loop) ends, old line will end and start new line for the 1st for loop
	}

	return 0;
}
