/* question no: 4
Suppose that x, y, and z are int variables, and x = 10, y = 15, and z = 20. Write a program that
will print the output of the following: */

#include <iostream>
using namespace std;


int x, y,z;
int main(){
	
	cout<<boolalpha<<"!(x > 10) = "<<!(x > 10);   //I use boolalpha to set bool format otherwise the output will be in binary form.
	
	cout<<"\n(x <= 5) || (y < 15) = "<<(x <= 5) || (y < 15);   
	
	cout<<"\n(x != 5) && (y != z) = "<<(x != 5) && (y != z);
	
	cout<<"\nx >= z || (x + y >= z) = "<<(x >= z) || (x + y >= z);
	
	cout<<"\n(x <= y - 2) && (y >= z) || (z - 2 != 20) = "<<(x <= y - 2) && (y >= z) || (z - 2 != 20);
	
return 0;
}
