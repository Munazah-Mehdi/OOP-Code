#include <iostream>
using namespace std;
float c, f;
int main()
{
	cout<<"Enter the temperature in centigrade =";
	cin>>c;
	
	f=(c*9/5)+32;
	cout<<"The temperature in Fahrenheit is = "<<f;
}
