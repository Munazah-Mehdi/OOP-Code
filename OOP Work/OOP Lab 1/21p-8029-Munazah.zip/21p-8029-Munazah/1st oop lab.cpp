#include <iostream>
using namespace std;

int main()
{
	cout<<"size of int = "<<sizeof(int)<<" bytes\n";
	cout<<"size of char = "<<sizeof(char)<<" bytes\n";
	cout<<"size of float = "<<sizeof(float)<<" bytes\n";
	cout<<"size of double = "<<sizeof(double)<<" bytes\n";
	cout<<"size of long = "<<sizeof(long)<<" bytes";
}
