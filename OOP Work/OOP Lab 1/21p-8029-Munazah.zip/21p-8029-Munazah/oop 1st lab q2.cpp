#include <iostream>
using namespace std;
char a;
int main()
{
	cout<<"Enter a character ";
	cin>>a;
	cout<<"ASCII of "<<a<<" is "<<int(a);
	
	
	return 0;
}
