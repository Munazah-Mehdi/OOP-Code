#include <iostream>
using namespace std;
int a,b;
int main()
{
 cout<<"Enter a number (a): ";
 cin>>a;
 cout<<"Enter anoter number which you want to swap(b): ";
 cin>>b;
 a=a*b;
 b=a/b;
 a=a/b;
 cout<<"The 1st num(a) is: "<<b<<endl;
 cout<<"The 2nd num(b) is: "<<a; 
 
 
 return 0;
}
