/*Write a C++ program that will add two 2D arrays elements. Note display values of 1st, 2nd and
their resultant array. */

#include <iostream>
using namespace std;
	
int main(){
	//declaring variables
	int i, j, add[i][j];
	
	//Declaring and intializing elements of matrix a
	int a[2][2]{1,2,3,4};
	
	//Declaring and intializing elements of matrix b	
	int b[2][2]{5,6,7,8};

	//displaying elements of matrix a
	cout<<"Elements of matrix a :"<<endl;	
	
	for  (int i=0;i<2;i++){    //loop for row
		for (int j=0; j<2; j++){  //loop for column
			cout<<a[i][j]<<"   ";  			
		}
		cout<<endl;  //end line after 1 one
	}
	cout<<"\n";  //an extra line for a neat code
	
	//displaying elements of matrix b
	cout<<"Elements of matrix b :"<<endl;	
	
	for  (int i=0;i<2;i++){       //loop for row
		for (int j=0; j<2; j++){  //loop for column
			cout<<b[i][j]<<"   ";
		}
		cout<<endl; //end line after 1 one
	}
	cout<<"\n";    //an extra line for a neat code
	
	
	//Adding matrix a and b
	cout<<"sum of matrix a and b is (aray num c) :"<<endl;
	for (int i=0; i<2; i++){
		for (int j=0; j<2; j++){
			add[i][j]=a[i][j]+b[i][j];    //adding nums of array using indexing
			cout<<add[i][j]<<"\t";
		}
		cout<<endl;
	}
}
