/*Write a C++ program to calculate cube of a number. Define two functions for calculating cube of
a number, one for �passing by value� and other for �passing by reference�.*/

#include <iostream>
#include <cmath>
using namespace std;

//ftn for pass by value
void passByvalue(int x){	
	int p=pow(x,3); //calculating cube of a num

	cout<<"\nPass by value= "<<p;
}

//ftn for pass by refrence
void passByRefrence(int *y) //pointer (*y)
{
	*y=pow(*y,3);      //calculating cube of a num present at that address 
 
	cout<<"\nPass by refrence = "<<*y<<endl;
}

int main(){
int a ,b;	
	cout<<"Enter 1st num= ";
	cin>>a;
	
	cout<<"Enter 2nd num= ";
	cin>>b;

//ftns call
	passByvalue(a);   //here i pass value of a, copy of a  will form and changes will occur in that copy.
	passByRefrence(&b);  //here i pass address of b, so the changes will made at the address of b.

//displaying nums after call	
	cout<<"\nnum 1 ="<<a<<"\nnum 2= "<<b;
	
	return 0;
}



//	int z=x;
//	x=y;
	
//	y=z;
