/*Write a C++ program that will take 10 integer inputs from user and store them in an array. Pass the
array to a function that will return the maximum integer. */

#include <iostream>
using namespace std;

//ftn for finding maximum
int maximum(int a[])  //here i pass indexing
{
	//1st store value at index 0 in varialbe 
     int max=a[0];  
	 
	//loop for finding max in an array  
    for(int i=0;i<10;i++){
     	if(a[i]>max)  //if value at current index is greater than max(the stored value in max)
		 {   
     		max=a[i]; //then rewrite max with the new greater value at current index
		 }}
		  return max;
		  }

int main(){
	
	int arr[10];
	//loop for input of array
		int a=1;
		cout<<"Enter up to 10 digits array "<<endl;		
	for (int i=0; i<10; i++){
        cout<<"Digit no "<<a<<" : ";
        a++;
		cin>>arr[i];
	}
	//loop for output of an array	
	    cout<<"\nYour array is : ";
	    cout<<"{";
		for (int i=0; i<10; i++){
    	cout<<arr[i]<<",";	
    }cout<<"}";
    	
    	cout<<"\nMaximum of an array:";
    	
    	//call for maximum ftn
		cout<<maximum(arr);
return 0;		
}

	


