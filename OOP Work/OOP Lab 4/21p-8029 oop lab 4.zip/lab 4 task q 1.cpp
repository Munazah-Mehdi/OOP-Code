/* Write a C++ program to print the factorial of a number by defining a function named 'Factorial'.
Calculate factorial of the number using loop.*/

#include <iostream> 

using namespace std;

	//ftn defination	
	int factorial(int x){
	int fac=1;
	
	//Calculating factorial of the number using loop.
	for (int i=1; i<=x; i++){
		
		 fac*=i;   // 5!=1*2*3*4*5=120
	}  
		 return fac;
	}

int main(){
	int a;  //variable declaration
	
	cout<<"Enter a number = ";
	cin>>a;

	cout<<"Factorial of "<<a<<" is = "<<factorial(a);	//calling ftn

	return 0;
	
	}
	




