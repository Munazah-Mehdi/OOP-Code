/*Write a program that uses a structure called point to model a point. Define three points, and have the user
input values to two of them. Then set the third point equal to the sum of the other two, and display the value
of the new point. */

#include <iostream>
using namespace std;
//structure 
struct point{
	
	//declaring members
	int x;
	int y;
};


int main(){
	
	//defining 3 objects
	point p1, p2, p3;
	
	//taking input for p1
	cout<<"Enter space after giving input of x"<<endl;
	cout<<"\nEnter x , y coordinates for p1 :   ";
	cin>>p1.x>>p1.y;
	

	
	//taking input for p2
	cout<<"Enter x , y coordinates for p2 :   ";
	cin>>p2.x>>p2.y;

	//adding x coordinates of p1 and p2
	p3.x=p1.x+p2.x;
	
	//adding 4 coordinates of p1 and p2
	p3.y=p1.y+p2.y;
	
	//displaying sum of x y coordinates of p1 and p2 using p3
	cout<<"\nx y Coordinates of p1+p2 are   :   "<<p3.x<<"  "<<p3.y;	
	
	return 0;
}
