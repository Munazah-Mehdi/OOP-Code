/*Write a C++ program to find the max of an integral data set. The program will ask the user to input the
number of data values in the set and each value. The program prints on screen a pointer that points to the
max value. */

#include <iostream>
using namespace std;

int main(){
	
	//declaring variable for size
	int s;
	
	//asking for size of an array from the user
	cout<<"Enter size of an array = ";
	cin>>s;
	
	cout<<endl; // printing extra line for neatness
	
	//declaring array
	int array[s];
	
	//taking input of an array from the user
	for (int i=0; i<s; i++){
		cout<<"Enter value of an array ["<<i+1<<"] = ";		
		cin>>array[i];
	}
	
	//declaring + assigning value of an array to pointer
	int *p=array;
	
	
	//declaring + assigning value in pointer to max
	int max=*p;
	
	//loop for finding max value using pointer
	for (int i=0; i<s; i++){
		if (*p>max){       //if value in pointer > value of max 
			max=*p;        // store that value in max variable
		
		}
	// incrementing of pointer for the next value address
		p++;              
	}
	
	//displaying  max value
			cout<<"\nMax value in an array is = "<<max;
			
	return 0;
	
}
