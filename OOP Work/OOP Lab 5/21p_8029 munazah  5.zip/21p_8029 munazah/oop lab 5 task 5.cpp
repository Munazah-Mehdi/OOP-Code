/*Take input in variable and display same value by pointer. 
Also display the memory address of the variable. */

#include <iostream>
using namespace std;


int main(){
	int a, b;
	cout<<"Enter value of a = ";
	cin>>a;
	
	//assigning address to pointer
	int *ptrA=&a;   

	//displaying value through pointer 
	cout<<"\nThe value of the variable using pointer = "<<*ptrA;
	
	//displaying address of variable
	cout<<"\nThe memory address of the variable is   = "<<ptrA;
	
	return 0;
	
}
