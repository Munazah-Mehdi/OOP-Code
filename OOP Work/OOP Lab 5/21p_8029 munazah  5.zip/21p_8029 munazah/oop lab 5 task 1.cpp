/*Create a structure called time. Its three members, all type int, should be called hours, minutes, and
seconds. Write a program that prompts the user to enter a time value in hours, minutes, and seconds. The
program should then store the time in a variable of type struct time, and finally print out the total number
of seconds. */

#include <iostream>
using namespace std;

//structure
struct time {
	//declaring members
	int hours;
	int minutes;
	int seconds;
	
	

};
//defining ftn for counting seconds
int ftntime(time t){	
     
     //applying formula : total no of seconds =hrs*3600 + min*60 + sec
	int seconds=(t.hours*3600)+(t.minutes*60)+(t.seconds);
	return seconds;
}	
	


int main(){
//definging object t of time
 time t;
 
 //taking input for hours from user
	cout<<"Enter hours   = ";
	cin>>t.hours;

 //taking input for minutes from user
	cout<<"Enter minutes = ";
	cin>>t.minutes;

 //taking input for seconds from user	
	cout<<"Enter seconds = ";
	cin>>t.seconds;

//calling ftntime 	
	int s=ftntime(t);
	
//displaying total no of seconds
	cout<<"\nTotal no. of seconds in "<<endl<<t.hours<<" hours: " <<t.minutes<<" minutes: "<<t.seconds<<" seconds:"<<endl<<"=  "<<s;
	
	return 0;
}
