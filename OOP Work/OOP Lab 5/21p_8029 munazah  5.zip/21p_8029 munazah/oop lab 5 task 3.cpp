/*Write a program that asks the user to enter integers as inputs to be stored in the variables 'a' and 'b'
respectively. There are also two integer pointers named ptrA and ptrB. Assign the values of 'a' and 'b' to
ptrA and ptrB respectively, and display them. */

#include <iostream>
using namespace std;

int main(){
	//declaring variables
	int a, b;
	
	//takinhg input for a
	cout<<"Enter value of a = ";
	cin>>a;
	
	//taking input for b
	cout<<"Enter value of b = "; 
	cin>>b;

//declaing + assigning address to pointers	
	int *ptrA=&a;    
	int *ptrB=&b;

/*displaying value through pointer. 
printing pointer which will display value present at that address. */
	cout<<"\nThe value of a using pointer = "<<*ptrA;    
	cout<<"\nThe value of b using pointer = "<<*ptrB;
	
	return 0;
}
