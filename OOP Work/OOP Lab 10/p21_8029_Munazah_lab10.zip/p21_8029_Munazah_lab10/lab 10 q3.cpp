//q3
/* Consider your semester project. Identify �is a� relationship between your classes and
code for at least one parent and one child class. Write a main program to test the inheritance. */

#include <iostream>

using namespace std;


enum Piece {king, queen, rook, bisop, knight, pawn, null};
enum Color{white, black, no};

class Abstract{
	private:
		int x, y;       //x, y coordinates
		Piece piece;    //have piece 
		Color color;    //which will also have color	
		
	public:
		//default constructor
		Abstract(){
			piece=null;
			color=no;
		}
		//parameterize constrauctor for piece and color 
		//this constructor will be use in derived classes
		Abstract(Piece p, Color c){
			piece=p;
			color=c;
		}
		//setting piece and color
		// this setter will be use in setting piece and its color on the board
		void set(Piece p, Color c){
			this->piece=p;
			this->color=c;
		}
		//getting piece and color
		Piece getpiece(){
			return piece;
		}
		
		Color getcolor(){
			return color;
		}
		
		void setnull(){
			piece=null;
			color=no;
		}
		
		
		//setting x and y
		void setx(int a){
			x=a;
		}
		
		void sety(int b){
			y=b;
		}
		//getting x and y
		int getx(){
			return x;
		}
		int gety(){
			return y;
		}
		
		//setter for settting piece(coming) from board
		void setpiece(Abstract* pi){
			this->color=pi->getcolor();
			this->piece=pi->getpiece();
		}		
	
	
};

//child class of Abract class
class King:public Abstract{
	private:
		char getpiece()
		{
		return 'K';
		}
		
		//here will be ftn for movements of King
		
	public:
		
		void Isrelation(){
			cout<<" There is a relation in King and Absract Class ";
		}
	
		//setting piece and color king
		King(){
			
		}
		King(Piece p, Color c):Abstract( p, c) {}
		~King() {}
};

class Board{
	private:
	     
		Abstract abstract[8][8];    //as 8 rows nd 8 colums
		void printboard(){
			//printing upper border
			cout<<"............................................................"<<endl;
			cout<<"  Y:    -0-  -1-    -2-    -3-     -4-     -5-    -6-   -7- "<<endl;
			cout<<"............................................................"<<endl;
			
			cout<<"  x: |"<<endl;
			
			//printing side border
			for (int i=0; i<8; i++ ){
				cout<<" -"<<i<<"- | ";  
				//printing pieces on board
				for (int j=0; j<8; j++ ){
					
					Piece p= abstract[i][j].getpiece();
					Color c=abstract[i][j].getcolor();
					
					switch(p){
						case king:
							//capital for white
							if(c==white){
								cout<<"  K   ";
							}
							//small for balck
							else{
								cout<<"   k  ";
							}
							break;
						case queen:
							if(c==white){
								cout<<"  Q   ";
							}
							else{
								cout<<"   q  ";
							}
							break;
						case bisop:
							if(c==white){
								cout<<"  B   ";
							}
							else{
								cout<<"   b  ";
							}
							break;
						case rook:
							if(c==white){
								cout<<"  R   ";
							}
							else{
								cout<<"   r  ";
							}
							break;
						case knight:
							if(c==white){
								cout<<"  N   ";
							}
							else{
								cout<<"   n  ";
							}
							break;
						case pawn:
							if(c==white){
								cout<<" P  ";
							}
							else{
								cout<<"  p  ";
							}
							break;
							
						case null:
							cout<<"  "<<"****"<<"  ";
							break;
				
				}
			}
			cout<<endl;
			
		}		

}

	public:

	
	Board(){
	//setting white pieces		
	abstract[0][0].set(rook, white);
	abstract[1][0].set(knight, white);
	abstract[2][0].set(bisop, white);
	abstract[3][0].set(queen, white);
	abstract[4][0].set(king, white);
	abstract[5][0].set(bisop, white);
	abstract[6][0].set(knight, white);
	abstract[7][0].set(rook, white);
	
	//setting black pieces
	abstract[0][7].set(rook, black);
	abstract[1][7].set(knight, black);
	abstract[2][7].set(bisop, black);
	abstract[3][7].set(queen, black);
	abstract[4][7].set(king, black);
	abstract[5][7].set(bisop, black);
	abstract[6][7].set(knight, black);
	abstract[7][7].set(rook, black);
	
	//setting pawn 
	for (int i = 0; i < 8; i++)
	{
		abstract[i][1].set(pawn, white);
		abstract[i][6].set(pawn, black);

	}
	//seting empty spaces
	for (int i = 2; i < 6; i++)
	{
		for (int j = 0; j < 8; j++)
			abstract[j][i].set(null, no);

	}
	//setting x, y coordinates
	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
		{
			abstract[i][j].setx(i);
			abstract[i][j].sety(j);
		}

}
	
		void details(){
			
			cout<<"....................................Welecome to the......................................."<<endl;
			cout << "\n   _____ _    _ ______  _____ _____        _____      ___      ____          ___________  \n ";
	   
			cout<<" / ____| |  | |  ____|/ ____/ ____|      / ____|    /   \\    |  _ \\        / _  |  ____|  \n";
	
			cout<<" | |    | |__| | |__  | (___| (___       | |        / ___ \\   | | \\ \\      / / | | |____  \n ";
	
			cout<<"| |    |  __  |  __|  \\___  \\___ \\      | |  ___  / /___\\ \\  | |  \\ \\    / /  | |  ____| \n";
	 
			cout<<" | |____| |  | | |____ ____) |___) |     | |____| /  _____  \\ | |   \\ \\  / /   | | |____  \n ";

			cout<<" \\_____|_|  |_|______|_____/_____/       \\_____|/_/       \\_\\|_|    \\_\\/_/    |_|______|\n" << endl;
	
			cout<<"...........................................................................................\n"<<endl;
		
	
			cout<<"             Capital letters for White ones "<<endl;
			cout<<"             Small letters for Black ones \n"<<endl;
		}
		
		//main ftn for dipalying
		bool Play(){
			details();
		  
			printboard();
			
		}
		
		
		
		
};






int main(){
	Board b;
	
	if (true){

		
	while(b.Play());
		
	}
	else{
		cout<<"OKAAYYY.....\n\nNo Problem, Thanks  for Comming";
		
	}
	
	cout<<"\n"<<endl;
	King k;
	k.Isrelation();
	cout<<endl;
		
	
	
	return 0;
}
