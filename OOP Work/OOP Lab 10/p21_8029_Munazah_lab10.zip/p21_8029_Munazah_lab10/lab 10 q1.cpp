//q1
/* Create a C++ program to read and print students information using two classes and
inheritance. */

#include <iostream>
using namespace std;

class student{
	protected:
		string name;
		int rollno;
		string department;
		string course;
		
	public:	
	
	void set_info(){
		
		//inputs fron user
		cout<<"Enter Name = ";
		cin>>name;
		cout<<"\nEnter ROll No = ";
		cin>>rollno; 
	
		cout<<"\nEnter department = ";
		cin>>department;
		cout<<"\nEnter course =  ";
		cin>>course; 
	
		}
		
		//displaying data
		void printdata(){
			cout<<"Name is = "<<name<<endl;
			cout<<"Roll No is = "<<rollno<<endl;
			cout<<"Deparment is = "<<department<<endl;
			cout<<"Course is = "<<course<<endl;
		}

};

class information:public student{
	private:
		float gpa;
		int semester;
	public:
	
	void info(){
		cout<<"\nEnter Gpa ";
		cin>>gpa;
		cout<<"\nEnter semester ";
		cin>>semester;
		}
		
		void showdata(){
			cout<<"GPA = "<<gpa<<endl;
			cout<<"Semester = "<<semester<<endl;
		}
};

int main(){
	information S1;
	S1.set_info();
	S1.info();
	S1.printdata();
	S1.showdata();
}
