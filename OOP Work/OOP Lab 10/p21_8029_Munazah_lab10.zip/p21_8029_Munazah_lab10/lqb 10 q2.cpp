//Q No.2: 
/*Consider a chef. The chef can make chicken, salad and a special dish. In addition to
this, an Italian chef can make pizza, pasta and his own special dish and a Chinese chef can make
fried rice. Identify classes and write C++ code. */


#include <iostream>
using namespace std;

class Chef{
	public:
		void display(){
			cout<<"Chef can make chicken, salad and a special dish "<<endl;
		}
		
};

class Italianchef: public Chef{
	public:
		void display(){
			cout<<"Italian chef can make pizza, pasta and his own a special dish"<<endl;
		}
	
};

class Chinesechef: public Chef{
	public:
		void display(){
			cout<<"Chinese chef can make fried rice and "<<endl;
		}
	
};

int main(){
	Chef chef1;
	chef1.display();
	
	Italianchef chef2;
	chef2.display();
	
	Chinesechef chef3;
	chef3.display();
	
	return 0;
}
